// Obter os elementos DOM para exibição do calendário e agendamentos
const daysElement = document.getElementById('days'); // Container dos dias do mês
const monthYearElement = document.getElementById('monthYear'); // Exibição do mês e ano atual
const appointmentsElement = document.getElementById('appointments'); // Exibição dos horários disponíveis e agendados

// Inicialização da data atual
let currentDate = new Date();

// Lista de horários disponíveis para alguns dias específicos (simulação de dados)
const schedule = {
    "1": ["09:00 - 10:00", "11:00 - 12:00", "14:00 - 15:00"], // Horários disponíveis para o dia 1
    "2": ["08:00 - 09:00", "10:00 - 11:00", "13:00 - 14:00"], // Horários disponíveis para o dia 2
    "3": ["09:00 - 10:00", "10:00 - 11:00", "15:00 - 16:00"], // Horários disponíveis para o dia 3
    "15": ["09:00 - 10:00", "10:00 - 11:00", "15:00 - 16:00"], // Horários disponíveis para o dia 15
    // Adicionar mais dias conforme necessário
};

// Objeto para armazenar os horários agendados para cada dia
const bookedAppointments = {};

// Função que renderiza o calendário
function renderCalendar() {
    currentDate.setDate(1); // Ajusta a data para o primeiro dia do mês
    const month = currentDate.getMonth(); // Obtém o mês atual
    const year = currentDate.getFullYear(); // Obtém o ano atual

    // Exibe o mês e ano atual no formato "Mês Ano" (ex: "outubro 2024")
    monthYearElement.innerText = currentDate.toLocaleString('pt-BR', { month: 'long', year: 'numeric' });

    // Descobre o primeiro dia da semana do mês (0 = domingo, 1 = segunda, ...)
    const firstDay = new Date(year, month, 1).getDay();

    // Obtém o número de dias no mês atual
    const lastDate = new Date(year, month + 1, 0).getDate();

    // Limpa o conteúdo de dias do mês anterior antes de renderizar novamente
    daysElement.innerHTML = '';

    // Cria as células em branco para os dias do mês anterior que não aparecem no calendário
    for (let i = 0; i < firstDay; i++) {
        daysElement.innerHTML += `<div class="day"></div>`;
    }

    // Cria os dias do mês atual, adicionando um evento de clique para exibir os horários disponíveis
    for (let i = 1; i <= lastDate; i++) {
        daysElement.innerHTML += `<div class="day" onclick="showAvailableTimes(${i}, ${month}, ${year})">${i}</div>`;
    }
}

// Função que exibe os horários disponíveis para um dia selecionado
function showAvailableTimes(day, month, year) {
    // Formato de data selecionada (ex: "1/10/2024")
    const selectedDay = `${day}/${month + 1}/${year}`;
    const availableTimes = schedule[day] || ["Nenhum horário disponível"]; // Horários disponíveis ou mensagem de falta de horários
    const bookedTimesForDay = bookedAppointments[selectedDay] || []; // Horários já agendados

    // Filtra os horários disponíveis removendo os horários já agendados
    const filteredTimes = availableTimes.filter(time => !bookedTimesForDay.includes(time));

    // Se não houver horários disponíveis, exibe mensagem indicando isso
    const timesToShow = filteredTimes.length > 0 ? filteredTimes : ["Nenhum horário disponível"];

    // Exibe os horários disponíveis para o dia selecionado
    appointmentsElement.innerHTML = `<h3>Horários disponíveis para ${selectedDay}:</h3>`;
    const ul = document.createElement('ul');

    // Para cada horário, cria um item de lista
    timesToShow.forEach(time => {
        const li = document.createElement('li');
        li.innerText = time;

        // Se não houver horários disponíveis, desabilita o clique e muda a aparência
        if (time === "Nenhum horário disponível") {
            li.style.cursor = "not-allowed"; // Muda o cursor para indicar que o horário não é clicável
            li.style.color = "#aaa"; // Muda a cor para indicar que o horário está desativado
        } else {
            // Adiciona um evento de clique para agendar o horário
            li.onclick = () => showBookingMessage(time, selectedDay);
        }

        // Adiciona o item de lista ao elemento de horários
        ul.appendChild(li);
    });

    // Adiciona os horários à exibição de agendamentos
    appointmentsElement.appendChild(ul);

    // Destaca o dia selecionado
    highlightSelectedDay(day);
}

// Função que exibe a mensagem de confirmação para agendar um horário
function showBookingMessage(time, day) {
    // Remove qualquer mensagem de agendamento anterior
    const existingMessage = document.querySelector('.booking-message');
    if (existingMessage) {
        existingMessage.remove();
    }

    // Cria uma nova mensagem de confirmação
    const messageElement = document.createElement('div');
    messageElement.className = 'booking-message';
    messageElement.innerText = `Deseja marcar o horário ${time} para o dia ${day}?`;

    // Botão "Sim" para confirmar o agendamento
    const yesButton = document.createElement('button');
    yesButton.innerText = 'Sim';
    yesButton.onclick = () => {
        confirmBooking(time, day); // Confirma o agendamento
        messageElement.remove(); // Remove a mensagem de confirmação
    };

    // Botão "Não" para cancelar o agendamento
    const noButton = document.createElement('button');
    noButton.innerText = 'Não';
    noButton.onclick = () => messageElement.remove(); // Remove a mensagem se o usuário clicar em "Não"

    // Adiciona os botões à mensagem
    messageElement.appendChild(yesButton);
    messageElement.appendChild(noButton);

    // Adiciona a mensagem de confirmação à exibição de agendamentos
    appointmentsElement.appendChild(messageElement);
}

// Função que confirma o agendamento do horário
function confirmBooking(time, day) {
    // Se ainda não houver agendamentos para o dia, inicializa uma lista
    if (!bookedAppointments[day]) {
        bookedAppointments[day] = [];
    }

    // Adiciona o horário agendado à lista de agendamentos
    bookedAppointments[day].push(time);

    // Atualiza a exibição para confirmar o agendamento
    appointmentsElement.innerHTML = `<h3>Horário ${time} no dia ${day} foi agendado com sucesso!</h3>`;
}

// Função que destaca o dia selecionado no calendário
function highlightSelectedDay(day) {
    const dayElements = document.querySelectorAll('.day');
    dayElements.forEach(el => {
        el.classList.remove('selected'); // Remove a classe de destaque de todos os dias
        if (el.innerText == day) {
            el.classList.add('selected'); // Adiciona a classe de destaque ao dia selecionado
        }
    });
}

// Eventos para navegar entre os meses (anterior e próximo)
document.getElementById('prev').addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() - 1); // Diminui o mês
    renderCalendar(); // Re-renderiza o calendário
});

document.getElementById('next').addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() + 1); // Aumenta o mês
    renderCalendar(); // Re-renderiza o calendário
});

// Inicializa o calendário na primeira exibição
renderCalendar();

/* Função para alternar o menu hamburguer */
function menuOnClick() {
    // Alterna as classes de CSS para abrir/fechar o menu lateral
    document.getElementById("menu-bar").classList.toggle("change");
    document.getElementById("nav").classList.toggle("change");
    document.getElementById("menu-bg").classList.toggle("change-bg");
}
