<script>
    // Inicialize o EmailJS com o seu serviço
    emailjs.init('YOUR_USER_ID'); // Substitua com o seu USER_ID obtido no painel do EmailJS

    // Função para enviar o e-mail
    document.getElementById('contact-form').addEventListener('submit', function(event) {
        event.preventDefault();

        // Pegue os dados do formulário
        var userName = document.getElementById('user_name').value;
        var userEmail = document.getElementById('user_email').value;
        var message = document.getElementById('message').value;

        var templateParams = {
            from_name: userName,
            from_email: userEmail,
            message: message
        };

        // Enviar o e-mail através do EmailJS
        emailjs.send('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', templateParams)
            .then(function(response) {
                alert('Mensagem enviada com sucesso!');
                console.log('Sucesso:', response);
            }, function(error) {
                alert('Falha ao enviar mensagem');
                console.log('Erro:', error);
            });
    });
</script>
