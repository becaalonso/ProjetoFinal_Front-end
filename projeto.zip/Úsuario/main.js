const daysElement = document.getElementById('days');
const monthYearElement = document.getElementById('monthYear');
const appointmentsElement = document.getElementById('appointments');

let currentDate = new Date();

// Lista de horários por dia (simulação de dados dinâmicos)
const schedule = {
    "1": ["09:00 - 10:00", "11:00 - 12:00", "14:00 - 15:00"],
    "2": ["08:00 - 09:00", "10:00 - 11:00", "13:00 - 14:00"],
    "3": ["09:00 - 10:00", "10:00 - 11:00", "15:00 - 16:00"],
    "15": ["09:00 - 10:00", "10:00 - 11:00", "15:00 - 16:00"],
    // Adicione mais dias conforme necessário...
};

// Objeto para armazenar os horários agendados
const bookedAppointments = {};

function renderCalendar() {
    currentDate.setDate(1);
    const month = currentDate.getMonth();
    const year = currentDate.getFullYear();

    monthYearElement.innerText = currentDate.toLocaleString('pt-BR', { month: 'long', year: 'numeric' });

    const firstDay = new Date(year, month, 1).getDay();
    const lastDate = new Date(year, month + 1, 0).getDate();

    daysElement.innerHTML = '';

    for (let i = 0; i < firstDay; i++) {
        daysElement.innerHTML += `<div class="day"></div>`;
    }

    for (let i = 1; i <= lastDate; i++) {
        daysElement.innerHTML += `<div class="day" onclick="showAvailableTimes(${i}, ${month}, ${year})">${i}</div>`;
    }
}

function showAvailableTimes(day, month, year) {
    const selectedDay = `${day}/${month + 1}/${year}`;
    const availableTimes = schedule[day] || ["Nenhum horário disponível"];
    const bookedTimesForDay = bookedAppointments[selectedDay] || [];

    // Filtrar os horários disponíveis removendo os já agendados
    const filteredTimes = availableTimes.filter(time => !bookedTimesForDay.includes(time));

    // Se não houver mais horários disponíveis, mostrar mensagem adequada
    const timesToShow = filteredTimes.length > 0 ? filteredTimes : ["Nenhum horário disponível"];

    appointmentsElement.innerHTML = `<h3>Horários disponíveis para ${selectedDay}:</h3>`;
    const ul = document.createElement('ul');

    timesToShow.forEach(time => {
        const li = document.createElement('li');
        li.innerText = time;

        // Verificar se o horário é "Nenhum horário disponível" e desabilitar clique
        if (time === "Nenhum horário disponível") {
            li.style.cursor = "not-allowed";  // Cursor alterado para indicar que não é clicável
            li.style.color = "#aaa";  // Mudança de cor para indicar que está desativado
        } else {
            li.onclick = () => showBookingMessage(time, selectedDay);
        }

        ul.appendChild(li);
    });

    appointmentsElement.appendChild(ul);
    highlightSelectedDay(day);
}

function showBookingMessage(time, day) {
    // Remover qualquer mensagem de confirmação anterior
    const existingMessage = document.querySelector('.booking-message');
    if (existingMessage) {
        existingMessage.remove();
    }

    const messageElement = document.createElement('div');
    messageElement.className = 'booking-message';

    messageElement.innerText = `Deseja marcar o horário ${time} para o dia ${day}?`;
    
    const yesButton = document.createElement('button');
    yesButton.innerText = 'Sim';
    yesButton.onclick = () => {
        confirmBooking(time, day);
        messageElement.remove(); // Remove a mensagem de confirmação
    };

    const noButton = document.createElement('button');
    noButton.innerText = 'Não';
    noButton.onclick = () => messageElement.remove(); // Remove a mensagem se o usuário clicar em Não

    messageElement.appendChild(yesButton);
    messageElement.appendChild(noButton);
    appointmentsElement.appendChild(messageElement);
}

function confirmBooking(time, day) {
    // Armazenar o horário agendado para o dia selecionado
    if (!bookedAppointments[day]) {
        bookedAppointments[day] = [];
    }
    bookedAppointments[day].push(time);

    // Atualizar a exibição para confirmar o agendamento
    appointmentsElement.innerHTML = `<h3>Horário ${time} no dia ${day} foi agendado com sucesso!</h3>`;
}

function highlightSelectedDay(day) {
    const dayElements = document.querySelectorAll('.day');
    dayElements.forEach(el => {
        el.classList.remove('selected');
        if (el.innerText == day) {
            el.classList.add('selected');
        }
    });
}

document.getElementById('prev').addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() - 1);
    renderCalendar();
});

document.getElementById('next').addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() + 1);
    renderCalendar();
});

renderCalendar();
