// Espera até que o conteúdo da página (DOM) esteja completamente carregado
document.addEventListener('DOMContentLoaded', function() {
  
  // Seleciona os elementos HTML necessários usando seus IDs
  const playButton = document.getElementById('play-button'); // Botão de play
  const video = document.getElementById('video'); // Elemento de vídeo
  const videoThumbnail = document.getElementById('video-thumbnail'); // Imagem de miniatura do vídeo
  const closeButton = document.getElementById('close-button'); // Botão de fechar o vídeo

  // Adiciona um ouvinte de evento no botão de play
  playButton.addEventListener('click', function() {
      // Quando o botão de play é clicado:
      videoThumbnail.style.display = 'none';  // Esconde a miniatura do vídeo
      video.style.display = 'block';          // Exibe o elemento de vídeo
      closeButton.style.display = 'block';   // Exibe o botão de fechar
      video.play();                          // Inicia a reprodução do vídeo
  });

  // Adiciona um ouvinte de evento no botão de fechar
  closeButton.addEventListener('click', function() {
      // Quando o botão de fechar é clicado:
      video.pause();                          // Pausa a reprodução do vídeo
      video.currentTime = 0;                   // Retorna o vídeo para o início
      video.style.display = 'none';            // Esconde o elemento de vídeo
      videoThumbnail.style.display = 'block';  // Exibe a miniatura do vídeo
      closeButton.style.display = 'none';     // Esconde o botão de fechar
  });
});

// Função para o comportamento do menu hambúrguer
function menuOnClick() {
  // Alterna a classe "change" nos elementos de menu para alterar a aparência (provavelmente para abrir/fechar o menu)
  document.getElementById("menu-bar").classList.toggle("change");
  document.getElementById("nav").classList.toggle("change");
  document.getElementById("menu-bg").classList.toggle("change-bg");
}
